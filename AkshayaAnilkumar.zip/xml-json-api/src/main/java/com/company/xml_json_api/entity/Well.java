package com.company.xml_json_api.entity;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.Instant;

@Entity
@Table(name = "wells")
public class Well {

    @Id
    @Column(nullable = false, unique = true)
    private String uid;

    @Column(nullable = false)
    private String name;

    private String nameLegal;
    private String field;
    private String country;
    private String state;
    private String county;
    private String region;
    private String block;
    private String timeZone;
    private String operator;
    private String numAPI;

    private Instant dTimSpud;

    private BigDecimal wellheadElevation;

    private String wellheadElevationUom;

    private Instant dTimCreation;
    private Instant dTimLastChange;

    private String itemState;

    private String defaultDatumUidRef;

    public Well() {
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameLegal() {
        return nameLegal;
    }

    public void setNameLegal(String nameLegal) {
        this.nameLegal = nameLegal;
    }

    public String getField() {
        return field;
    }

    public void setField(String field) {
        this.field = field;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getBlock() {
        return block;
    }

    public void setBlock(String block) {
        this.block = block;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }

    public String getNumAPI() {
        return numAPI;
    }

    public void setNumAPI(String numAPI) {
        this.numAPI = numAPI;
    }

    public Instant getdTimSpud() {
        return dTimSpud;
    }

    public void setdTimSpud(Instant dTimSpud) {
        this.dTimSpud = dTimSpud;
    }

    public BigDecimal getWellheadElevation() {
        return wellheadElevation;
    }

    public void setWellheadElevation(BigDecimal wellheadElevation) {
        this.wellheadElevation = wellheadElevation;
    }

    public String getWellheadElevationUom() {
        return wellheadElevationUom;
    }

    public void setWellheadElevationUom(String wellheadElevationUom) {
        this.wellheadElevationUom = wellheadElevationUom;
    }

    public Instant getdTimCreation() {
        return dTimCreation;
    }

    public void setdTimCreation(Instant dTimCreation) {
        this.dTimCreation = dTimCreation;
    }

    public Instant getdTimLastChange() {
        return dTimLastChange;
    }

    public void setdTimLastChange(Instant dTimLastChange) {
        this.dTimLastChange = dTimLastChange;
    }

    public String getItemState() {
        return itemState;
    }

    public void setItemState(String itemState) {
        this.itemState = itemState;
    }

    public String getDefaultDatumUidRef() {
        return defaultDatumUidRef;
    }

    public void setDefaultDatumUidRef(String defaultDatumUidRef) {
        this.defaultDatumUidRef = defaultDatumUidRef;
    }
}