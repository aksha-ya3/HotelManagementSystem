package com.company.xml_json_api.parser;

import com.company.xml_json_api.dto.CommonDataDto;
import com.company.xml_json_api.dto.WellDto;
import com.company.xml_json_api.exception.InvalidXmlException;
import org.springframework.stereotype.Component;
import org.w3c.dom.*;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@Component
public class WitsmlXmlParser {

    private static final String WITSML_NAMESPACE =
            "http://www.witsml.org/schemas/1series";

    public List<WellDto> parse(String xmlContent) {

        try {

            DocumentBuilderFactory factory =
                    DocumentBuilderFactory.newInstance();

            factory.setNamespaceAware(true);

            factory.setFeature(
                    "http://apache.org/xml/features/disallow-doctype-decl",
                    true);

            factory.setFeature(
                    "http://xml.org/sax/features/external-general-entities",
                    false);

            factory.setFeature(
                    "http://xml.org/sax/features/external-parameter-entities",
                    false);

            factory.setFeature(
                    "http://apache.org/xml/features/nonvalidating/load-external-dtd",
                    false);

            factory.setAttribute(
                    XMLConstants.ACCESS_EXTERNAL_DTD,
                    "");

            factory.setAttribute(
                    XMLConstants.ACCESS_EXTERNAL_SCHEMA,
                    "");

            DocumentBuilder builder = factory.newDocumentBuilder();

            Document document = builder.parse(
                    new ByteArrayInputStream(
                            xmlContent.getBytes(StandardCharsets.UTF_8)));

            Element root = document.getDocumentElement();

            if (!"wells".equals(root.getLocalName())) {
                throw new InvalidXmlException(
                        "Root element must be <wells>.");
            }

            if (!WITSML_NAMESPACE.equals(root.getNamespaceURI())) {
                throw new InvalidXmlException(
                        "Invalid WITSML namespace.");
            }

            NodeList wellNodes =
                    root.getElementsByTagNameNS(
                            WITSML_NAMESPACE,
                            "well");

            if (wellNodes.getLength() == 0) {
                throw new InvalidXmlException(
                        "No well records found in XML.");
            }

            List<WellDto> wells = new ArrayList<>();

            for (int i = 0; i < wellNodes.getLength(); i++) {

                Element wellElement =
                        (Element) wellNodes.item(i);

                WellDto well = parseWell(wellElement);

                wells.add(well);
            }

            return wells;

        } catch (InvalidXmlException exception) {

            throw exception;

        } catch (Exception exception) {

            throw new InvalidXmlException(
                    "Unable to parse WITSML XML.",
                    exception);
        }
    }

    private WellDto parseWell(Element element) {

        WellDto well = new WellDto();

        well.setUid(element.getAttribute("uid"));

        well.setName(getText(element, "name"));
        well.setNameLegal(getText(element, "nameLegal"));
        well.setField(getText(element, "field"));
        well.setCountry(getText(element, "country"));
        well.setState(getText(element, "state"));
        well.setCounty(getText(element, "county"));
        well.setRegion(getText(element, "region"));
        well.setBlock(getText(element, "block"));
        well.setTimeZone(getText(element, "timeZone"));
        well.setOperator(getText(element, "operator"));
        well.setNumAPI(getText(element, "numAPI"));

        String spudDate = getText(element, "dTimSpud");

        if (spudDate != null) {
            well.setdTimSpud(Instant.parse(spudDate));
        }

        Element elevation =
                getElement(element, "wellheadElevation");

        if (elevation != null) {

            String value = elevation.getTextContent().trim();

            if (!value.isEmpty()) {
                well.setWellheadElevation(
                        new BigDecimal(value));
            }

            well.setWellheadElevationUom(
                    elevation.getAttribute("uom"));
        }

        Element commonData =
                getElement(element, "commonData");

        if (commonData != null) {

            CommonDataDto commonDataDto =
                    new CommonDataDto();

            String creation =
                    getText(commonData, "dTimCreation");

            if (creation != null) {
                commonDataDto.setdTimCreation(
                        Instant.parse(creation));
            }

            String lastChange =
                    getText(commonData, "dTimLastChange");

            if (lastChange != null) {
                commonDataDto.setdTimLastChange(
                        Instant.parse(lastChange));
            }

            commonDataDto.setItemState(
                    getText(commonData, "itemState"));

            Element defaultDatum =
                    getElement(commonData, "defaultDatum");

            if (defaultDatum != null) {

                commonDataDto.setDefaultDatumUidRef(
                        defaultDatum.getAttribute("uidRef"));
            }

            well.setCommonData(commonDataDto);
        }

        return well;
    }

    private String getText(
            Element parent,
            String elementName) {

        Element element =
                getElement(parent, elementName);

        if (element == null) {
            return null;
        }

        String value =
                element.getTextContent();

        return value == null || value.isBlank()
                ? null
                : value.trim();
    }

    private Element getElement(
            Element parent,
            String elementName) {

        NodeList nodes =
                parent.getElementsByTagNameNS(
                        WITSML_NAMESPACE,
                        elementName);

        if (nodes.getLength() == 0) {
            return null;
        }

        return (Element) nodes.item(0);
    }
}