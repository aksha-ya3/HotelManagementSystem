package com.company.xml_json_api.service;

import com.company.xml_json_api.dto.UploadResponseDto;
import com.company.xml_json_api.entity.UploadedFile;
import com.company.xml_json_api.enums.ProcessingStatus;
import com.company.xml_json_api.exception.InvalidFileException;
import com.company.xml_json_api.repository.UploadedFileRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.UUID;

@Service
public class UploadService {

    private final UploadedFileRepository uploadedFileRepository;
    private final XmlProcessingService xmlProcessingService;

    @Value("${app.storage.xml-directory:uploads}")
    private String xmlStorageDirectory;

    public UploadService(
            UploadedFileRepository uploadedFileRepository,
            XmlProcessingService xmlProcessingService) {

        this.uploadedFileRepository = uploadedFileRepository;
        this.xmlProcessingService = xmlProcessingService;
    }

    public UploadResponseDto uploadFile(MultipartFile file) {

        validateFile(file);

        UUID fileId = UUID.randomUUID();

        try {

            Path storagePath =
                    Paths.get(xmlStorageDirectory);

            Files.createDirectories(storagePath);

            String storedFileName =
                    fileId + ".xml";

            Path xmlFilePath =
                    storagePath.resolve(storedFileName);

            Files.copy(
                    file.getInputStream(),
                    xmlFilePath);

            UploadedFile uploadedFile =
                    new UploadedFile();

            uploadedFile.setFileId(fileId);

            uploadedFile.setOriginalFilename(
                    file.getOriginalFilename());

            uploadedFile.setStatus(
                    ProcessingStatus.PROCESSING);

            uploadedFile.setUploadedAt(
                    LocalDateTime.now());

            uploadedFile.setTempFilePath(
                    xmlFilePath.toAbsolutePath().toString());

            uploadedFileRepository.save(uploadedFile);

            /*
             * Start background processing.
             * API does not wait for processing to finish.
             */
            xmlProcessingService.processXmlAsync(
                    fileId,
                    file.getOriginalFilename(),
                    xmlFilePath.toAbsolutePath().toString());

            return new UploadResponseDto(
                    fileId,
                    ProcessingStatus.PROCESSING.name(),
                    "File uploaded successfully. Processing has started.");

        } catch (IOException exception) {

            throw new InvalidFileException(
                    "Unable to store uploaded XML file.");
        }
    }

    private void validateFile(MultipartFile file) {

        if (file == null || file.isEmpty()) {

            throw new InvalidFileException(
                    "XML file is required and must not be empty.");
        }

        String originalFilename =
                file.getOriginalFilename();

        if (originalFilename == null
                || originalFilename.isBlank()) {

            throw new InvalidFileException(
                    "File name is required.");
        }

        if (!originalFilename
                .toLowerCase()
                .endsWith(".xml")) {

            throw new InvalidFileException(
                    "Only XML files are allowed.");
        }
    }
}