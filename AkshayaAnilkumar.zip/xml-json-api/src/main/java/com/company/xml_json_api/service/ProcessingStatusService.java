package com.company.xml_json_api.service;

import com.company.xml_json_api.dto.ProcessingStatusDto;
import com.company.xml_json_api.entity.UploadedFile;
import com.company.xml_json_api.exception.FileNotFoundException;
import com.company.xml_json_api.repository.UploadedFileRepository;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class ProcessingStatusService {

    private final UploadedFileRepository uploadedFileRepository;

    public ProcessingStatusService(
            UploadedFileRepository uploadedFileRepository) {

        this.uploadedFileRepository =
                uploadedFileRepository;
    }

    public ProcessingStatusDto getStatus(UUID fileId) {

        UploadedFile uploadedFile =
                uploadedFileRepository
                        .findById(fileId)
                        .orElseThrow(() ->
                                new FileNotFoundException(
                                        "No uploaded file found for ID: "
                                                + fileId));

        return new ProcessingStatusDto(
                uploadedFile.getFileId(),
                uploadedFile.getOriginalFilename(),
                uploadedFile.getStatus(),
                uploadedFile.getUploadedAt(),
                uploadedFile.getCompletedAt(),
                uploadedFile.getErrorMessage());
    }
}