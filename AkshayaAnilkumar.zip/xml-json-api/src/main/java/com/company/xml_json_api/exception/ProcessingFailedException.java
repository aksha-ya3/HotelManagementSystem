package com.company.xml_json_api.exception;

public class ProcessingFailedException extends RuntimeException {

    public ProcessingFailedException(String message) {
        super(message);
    }
}