package com.company.xml_json_api.service;

import com.company.xml_json_api.dto.WellDto;
import com.company.xml_json_api.entity.UploadedFile;
import com.company.xml_json_api.enums.ProcessingStatus;
import com.company.xml_json_api.parser.WitsmlXmlParser;
import com.company.xml_json_api.repository.UploadedFileRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class XmlProcessingService {

    private static final Logger log =
            LoggerFactory.getLogger(XmlProcessingService.class);

    private final WitsmlXmlParser witsmlXmlParser;
    private final WellService wellService;
    private final JsonStorageService jsonStorageService;
    private final UploadedFileRepository uploadedFileRepository;
    private final ObjectMapper objectMapper;

    public XmlProcessingService(
            WitsmlXmlParser witsmlXmlParser,
            WellService wellService,
            JsonStorageService jsonStorageService,
            UploadedFileRepository uploadedFileRepository,
            ObjectMapper objectMapper) {

        this.witsmlXmlParser = witsmlXmlParser;
        this.wellService = wellService;
        this.jsonStorageService = jsonStorageService;
        this.uploadedFileRepository = uploadedFileRepository;
        this.objectMapper = objectMapper;
    }

    @Async("xmlProcessingExecutor")
    public void processXmlAsync(
            UUID fileId,
            String fileName,
            String filePath) {

        log.info(
                "Started background XML processing. fileId={}, fileName={}",
                fileId,
                fileName);

        Path xmlPath =
                Paths.get(filePath);

        try {

            if (!Files.exists(xmlPath)) {

                updateStatus(
                        fileId,
                        ProcessingStatus.FAILED,
                        "Uploaded XML file was not found.");

                return;
            }

            String xmlContent =
                    Files.readString(xmlPath);

            if (xmlContent.isBlank()) {

                updateStatus(
                        fileId,
                        ProcessingStatus.FAILED,
                        "XML file is empty.");

                return;
            }

            log.info(
                    "XML file successfully read. fileId={}",
                    fileId);

            List<WellDto> wellDtos =
                    witsmlXmlParser.parse(xmlContent);

            log.info(
                    "XML parsing completed. fileId={}, count={}",
                    fileId,
                    wellDtos.size());

            wellService.saveWells(wellDtos);

            log.info(
                    "Well records saved successfully. fileId={}",
                    fileId);

            Map<String, Object> jsonResponse =
                    new HashMap<>();

            jsonResponse.put("wells", wellDtos);

            String jsonContent =
                    objectMapper
                            .writerWithDefaultPrettyPrinter()
                            .writeValueAsString(jsonResponse);

            jsonStorageService.storeJson(
                    fileId,
                    jsonContent);

            log.info(
                    "JSON stored in application memory. fileId={}",
                    fileId);

            /*
             * Delete temporary XML before marking
             * the operation as completed.
             */
            Files.deleteIfExists(xmlPath);

            updateStatus(
                    fileId,
                    ProcessingStatus.COMPLETED,
                    null);

            log.info(
                    "XML processing completed successfully. fileId={}",
                    fileId);

        } catch (Exception exception) {

            log.error(
                    "XML processing failed. fileId={}",
                    fileId,
                    exception);

            updateStatus(
                    fileId,
                    ProcessingStatus.FAILED,
                    exception.getMessage());
        }
    }

    private void updateStatus(
            UUID fileId,
            ProcessingStatus status,
            String errorMessage) {

        UploadedFile uploadedFile =
                uploadedFileRepository
                        .findById(fileId)
                        .orElse(null);

        if (uploadedFile == null) {

            log.error(
                    "Uploaded file record not found. fileId={}",
                    fileId);

            return;
        }

        uploadedFile.setStatus(status);

        uploadedFile.setCompletedAt(
                LocalDateTime.now());

        uploadedFile.setErrorMessage(
                errorMessage);

        uploadedFileRepository.save(uploadedFile);
    }
}