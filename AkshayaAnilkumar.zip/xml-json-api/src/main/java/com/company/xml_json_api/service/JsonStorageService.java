package com.company.xml_json_api.service;

import org.springframework.stereotype.Service;

import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

@Service
public class JsonStorageService {

    private final ConcurrentMap<UUID, String> jsonStorage =
            new ConcurrentHashMap<>();

    public void storeJson(UUID fileId, String jsonContent) {

        if (fileId == null) {
            throw new IllegalArgumentException(
                    "File ID cannot be null.");
        }

        if (jsonContent == null || jsonContent.isBlank()) {
            throw new IllegalArgumentException(
                    "JSON content cannot be empty.");
        }

        jsonStorage.put(fileId, jsonContent);
    }

    public String getJson(UUID fileId) {
        return jsonStorage.get(fileId);
    }

    public boolean contains(UUID fileId) {
        return jsonStorage.containsKey(fileId);
    }

    public void removeJson(UUID fileId) {
        jsonStorage.remove(fileId);
    }
}