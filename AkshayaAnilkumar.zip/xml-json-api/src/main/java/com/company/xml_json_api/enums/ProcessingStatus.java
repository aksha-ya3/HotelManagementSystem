package com.company.xml_json_api.enums;

public enum ProcessingStatus {

    PROCESSING,
    COMPLETED,
    FAILED
}