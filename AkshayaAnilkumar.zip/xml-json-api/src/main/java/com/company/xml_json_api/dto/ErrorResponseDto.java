package com.company.xml_json_api.dto;

import lombok.Data;

@Data 
public class ErrorResponseDto {

    private int status;
    private String error;
    private String message;

    public ErrorResponseDto() {
    }

    public ErrorResponseDto(
            int status,
            String error,
            String message) {

        this.status = status;
        this.error = error;
        this.message = message;
    }

    // getters and setters
}