package com.company.xml_json_api.service;

import com.company.xml_json_api.dto.WellDto;
import com.company.xml_json_api.entity.Well;
import com.company.xml_json_api.exception.WellNotFoundException;
import com.company.xml_json_api.repository.WellRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WellService {

    private final WellRepository wellRepository;

    public WellService(WellRepository wellRepository) {
        this.wellRepository = wellRepository;
    }

    public List<Well> saveWells(List<WellDto> wellDtos) {

        List<Well> validWells = wellDtos.stream()
                .filter(this::isValidWell)
                .map(this::convertToEntity)
                .toList();

        if (validWells.isEmpty()) {
            throw new IllegalArgumentException(
                    "No valid well records found.");
        }

        return wellRepository.saveAll(validWells);
    }

    public List<Well> getAllWells() {
        return wellRepository.findAll();
    }

    public Well getWellByUid(String uid) {

        return wellRepository.findById(uid)
                .orElseThrow(() ->
                        new WellNotFoundException(
                                "No well found for UID: " + uid));
    }

    private boolean isValidWell(WellDto dto) {

        return dto != null
                && dto.getUid() != null
                && !dto.getUid().isBlank()
                && dto.getName() != null
                && !dto.getName().isBlank();
    }

    private Well convertToEntity(WellDto dto) {

        Well well = new Well();

        well.setUid(dto.getUid());
        well.setName(dto.getName());
        well.setNameLegal(dto.getNameLegal());
        well.setField(dto.getField());
        well.setCountry(dto.getCountry());
        well.setState(dto.getState());
        well.setCounty(dto.getCounty());
        well.setRegion(dto.getRegion());
        well.setBlock(dto.getBlock());
        well.setTimeZone(dto.getTimeZone());
        well.setOperator(dto.getOperator());
        well.setNumAPI(dto.getNumAPI());

        well.setdTimSpud(dto.getdTimSpud());

        well.setWellheadElevation(
                dto.getWellheadElevation());

        well.setWellheadElevationUom(
                dto.getWellheadElevationUom());

        if (dto.getCommonData() != null) {

            well.setdTimCreation(
                    dto.getCommonData().getdTimCreation());

            well.setdTimLastChange(
                    dto.getCommonData().getdTimLastChange());

            well.setItemState(
                    dto.getCommonData().getItemState());

            well.setDefaultDatumUidRef(
                    dto.getCommonData().getDefaultDatumUidRef());
        }

        return well;
    }
}