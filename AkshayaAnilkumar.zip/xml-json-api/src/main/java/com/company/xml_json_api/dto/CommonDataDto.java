package com.company.xml_json_api.dto;

import java.time.Instant;

import lombok.Data;
@Data 
public class CommonDataDto {

    private Instant dTimCreation;
    private Instant dTimLastChange;
    private String itemState;
    private String defaultDatumUidRef;

    public CommonDataDto() {
    }

    public Instant getdTimCreation() {
        return dTimCreation;
    }

    public void setdTimCreation(Instant dTimCreation) {
        this.dTimCreation = dTimCreation;
    }

    public Instant getdTimLastChange() {
        return dTimLastChange;
    }

    public void setdTimLastChange(Instant dTimLastChange) {
        this.dTimLastChange = dTimLastChange;
    }

    public String getItemState() {
        return itemState;
    }

    public void setItemState(String itemState) {
        this.itemState = itemState;
    }

    public String getDefaultDatumUidRef() {
        return defaultDatumUidRef;
    }

    public void setDefaultDatumUidRef(String defaultDatumUidRef) {
        this.defaultDatumUidRef = defaultDatumUidRef;
    }
}