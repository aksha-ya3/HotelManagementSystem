package com.company.xml_json_api.dto;

import com.company.xml_json_api.enums.ProcessingStatus;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;
@Data 
public class ProcessingStatusDto {

    private UUID fileId;
    private String originalFilename;
    private ProcessingStatus status;
    private LocalDateTime uploadedAt;
    private LocalDateTime completedAt;
    private String errorMessage;

    public ProcessingStatusDto() {
    }

    public ProcessingStatusDto(
            UUID fileId,
            String originalFilename,
            ProcessingStatus status,
            LocalDateTime uploadedAt,
            LocalDateTime completedAt,
            String errorMessage) {

        this.fileId = fileId;
        this.originalFilename = originalFilename;
        this.status = status;
        this.uploadedAt = uploadedAt;
        this.completedAt = completedAt;
        this.errorMessage = errorMessage;
    }

}