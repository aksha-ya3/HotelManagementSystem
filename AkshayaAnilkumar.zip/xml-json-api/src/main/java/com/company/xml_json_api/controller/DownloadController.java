package com.company.xml_json_api.controller;

import com.company.xml_json_api.service.DownloadService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

@RestController
@RequestMapping("/api")
public class DownloadController {

    private final DownloadService downloadService;

    public DownloadController(
            DownloadService downloadService) {

        this.downloadService = downloadService;
    }

    @GetMapping("/download/{fileId}")
    public ResponseEntity<byte[]> download(
            @PathVariable UUID fileId) {

        String jsonContent =
                downloadService.getJsonForDownload(fileId);

        return ResponseEntity.ok()
                .header(
                        HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"" +
                                fileId +
                                ".json\"")
                .contentType(MediaType.APPLICATION_JSON)
                .body(
                        jsonContent.getBytes(
                                StandardCharsets.UTF_8));
    }
}