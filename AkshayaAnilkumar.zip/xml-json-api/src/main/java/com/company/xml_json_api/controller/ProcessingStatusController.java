package com.company.xml_json_api.controller;

import com.company.xml_json_api.dto.ProcessingStatusDto;
import com.company.xml_json_api.service.ProcessingStatusService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api")
public class ProcessingStatusController {

    private final ProcessingStatusService processingStatusService;

    public ProcessingStatusController(
            ProcessingStatusService processingStatusService) {

        this.processingStatusService =
                processingStatusService;
    }

    @GetMapping("/status/{fileId}")
    public ResponseEntity<ProcessingStatusDto> getStatus(
            @PathVariable UUID fileId) {

        return ResponseEntity.ok(
                processingStatusService.getStatus(fileId));
    }
}