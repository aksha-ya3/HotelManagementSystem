package com.company.xml_json_api.exception;

public class WellNotFoundException extends RuntimeException {

    public WellNotFoundException(String message) {
        super(message);
    }
}