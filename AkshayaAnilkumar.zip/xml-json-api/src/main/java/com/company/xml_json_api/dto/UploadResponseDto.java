package com.company.xml_json_api.dto;

import java.util.UUID;

import lombok.Data;
@Data 
public class UploadResponseDto {

    private UUID fileId;
    private String status;
    private String message;

    public UploadResponseDto() {
    }

    public UploadResponseDto(UUID fileId, String status, String message) {
        this.fileId = fileId;
        this.status = status;
        this.message = message;
    }
}