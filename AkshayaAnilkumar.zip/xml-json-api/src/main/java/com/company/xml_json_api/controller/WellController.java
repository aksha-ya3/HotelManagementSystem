package com.company.xml_json_api.controller;

import com.company.xml_json_api.entity.Well;
import com.company.xml_json_api.service.WellService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/wells")
public class WellController {

    private final WellService wellService;

    public WellController(WellService wellService) {
        this.wellService = wellService;
    }

    @GetMapping
    public ResponseEntity<List<Well>> getAllWells() {

        return ResponseEntity.ok(
                wellService.getAllWells());
    }

    @GetMapping("/{uid}")
    public ResponseEntity<Well> getWellByUid(
            @PathVariable String uid) {

        return ResponseEntity.ok(
                wellService.getWellByUid(uid));
    }
}