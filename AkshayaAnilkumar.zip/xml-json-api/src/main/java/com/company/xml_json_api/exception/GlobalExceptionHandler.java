package com.company.xml_json_api.exception;

import com.company.xml_json_api.dto.ErrorResponseDto;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(FileNotFoundException.class)
    public ResponseEntity<ErrorResponseDto> handleFileNotFound(
            FileNotFoundException exception) {

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(new ErrorResponseDto(
                        404,
                        "FILE_NOT_FOUND",
                        exception.getMessage()));
    }

    @ExceptionHandler(InvalidFileException.class)
    public ResponseEntity<ErrorResponseDto> handleInvalidFile(
            InvalidFileException exception) {

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(new ErrorResponseDto(
                        400,
                        "INVALID_FILE",
                        exception.getMessage()));
    }

    @ExceptionHandler(InvalidXmlException.class)
    public ResponseEntity<ErrorResponseDto> handleInvalidXml(
            InvalidXmlException exception) {

        return ResponseEntity
                .status(HttpStatus.BAD_REQUEST)
                .body(new ErrorResponseDto(
                        400,
                        "INVALID_XML",
                        exception.getMessage()));
    }

    @ExceptionHandler(ProcessingInProgressException.class)
    public ResponseEntity<ErrorResponseDto> handleProcessingInProgress(
            ProcessingInProgressException exception) {

        return ResponseEntity
                .status(HttpStatus.CONFLICT)
                .body(new ErrorResponseDto(
                        409,
                        "PROCESSING_IN_PROGRESS",
                        exception.getMessage()));
    }

    @ExceptionHandler(ProcessingFailedException.class)
    public ResponseEntity<ErrorResponseDto> handleProcessingFailed(
            ProcessingFailedException exception) {

        return ResponseEntity
                .status(HttpStatus.UNPROCESSABLE_CONTENT)
                .body(new ErrorResponseDto(
                        422,
                        "PROCESSING_FAILED",
                        exception.getMessage()));
    }

    @ExceptionHandler(WellNotFoundException.class)
    public ResponseEntity<ErrorResponseDto> handleWellNotFound(
            WellNotFoundException exception) {

        return ResponseEntity
                .status(HttpStatus.NOT_FOUND)
                .body(new ErrorResponseDto(
                        404,
                        "WELL_NOT_FOUND",
                        exception.getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponseDto> handleUnexpectedException(
            Exception exception) {

        return ResponseEntity
                .status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(new ErrorResponseDto(
                        500,
                        "INTERNAL_SERVER_ERROR",
                        "An unexpected error occurred."));
    }
}