package com.company.xml_json_api.repository;

import com.company.xml_json_api.entity.Well;
import org.springframework.data.jpa.repository.JpaRepository;

public interface WellRepository extends JpaRepository<Well, String> {
}