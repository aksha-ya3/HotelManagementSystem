package com.company.xml_json_api.service;

import com.company.xml_json_api.entity.UploadedFile;
import com.company.xml_json_api.enums.ProcessingStatus;
import com.company.xml_json_api.exception.FileNotFoundException;
import com.company.xml_json_api.exception.ProcessingFailedException;
import com.company.xml_json_api.exception.ProcessingInProgressException;
import com.company.xml_json_api.repository.UploadedFileRepository;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class DownloadService {

    private final JsonStorageService jsonStorageService;
    private final UploadedFileRepository uploadedFileRepository;

    public DownloadService(
            JsonStorageService jsonStorageService,
            UploadedFileRepository uploadedFileRepository) {

        this.jsonStorageService = jsonStorageService;
        this.uploadedFileRepository = uploadedFileRepository;
    }

    public String getJsonForDownload(UUID fileId) {

        UploadedFile uploadedFile =
                uploadedFileRepository
                        .findById(fileId)
                        .orElseThrow(() ->
                                new FileNotFoundException(
                                        "No uploaded file found for ID: "
                                                + fileId));

        if (uploadedFile.getStatus()
                == ProcessingStatus.PROCESSING) {

            throw new ProcessingInProgressException(
                    "File processing is still in progress. "
                            + "Please try again later.");
        }

        if (uploadedFile.getStatus()
                == ProcessingStatus.FAILED) {

            throw new ProcessingFailedException(
                    "File processing failed: "
                            + uploadedFile.getErrorMessage());
        }

        String jsonContent =
                jsonStorageService.getJson(fileId);

        if (jsonContent == null) {

            throw new FileNotFoundException(
                    "Processed JSON is not available for file ID: "
                            + fileId);
        }

        return jsonContent;
    }
}