package com.company.xml_json_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication
@EnableAsync 
public class XmlJsonApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(XmlJsonApiApplication.class, args);
	}

}
