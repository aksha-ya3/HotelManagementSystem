package com.company.xml_json_api.controller;

import com.company.xml_json_api.dto.UploadResponseDto;
import com.company.xml_json_api.service.UploadService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api")
public class UploadController {

    private final UploadService uploadService;

    public UploadController(UploadService uploadService) {
        this.uploadService = uploadService;
    }

    @PostMapping("/upload")
    public ResponseEntity<UploadResponseDto> upload(
            @RequestParam("file") MultipartFile file) {

        return ResponseEntity.ok(
                uploadService.uploadFile(file));
    }
}