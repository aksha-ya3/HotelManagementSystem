package com.company.xml_json_api.exception;

public class ProcessingInProgressException extends RuntimeException {

    public ProcessingInProgressException(String message) {
        super(message);
    }
}