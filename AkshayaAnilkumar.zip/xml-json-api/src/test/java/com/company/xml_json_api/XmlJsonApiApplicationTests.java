package com.company.xml_json_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XmlJsonApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
